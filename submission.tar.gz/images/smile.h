/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 smile smile.png 
 * Time-stamp: Tuesday 04/02/2024, 23:56:16
 * 
 * Image Information
 * -----------------
 * smile.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SMILE_H
#define SMILE_H

extern const unsigned short smile[625];
#define SMILE_SIZE 1250
#define SMILE_LENGTH 625
#define SMILE_WIDTH 25
#define SMILE_HEIGHT 25

#endif

