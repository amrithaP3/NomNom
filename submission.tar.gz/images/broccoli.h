/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 broccoli broccoli.png 
 * Time-stamp: Tuesday 04/02/2024, 14:38:44
 * 
 * Image Information
 * -----------------
 * broccoli.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BROCCOLI_H
#define BROCCOLI_H

extern const unsigned short broccoli[225];
#define BROCCOLI_SIZE 450
#define BROCCOLI_LENGTH 225
#define BROCCOLI_WIDTH 15
#define BROCCOLI_HEIGHT 15

#endif

