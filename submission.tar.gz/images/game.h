/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 game game.png 
 * Time-stamp: Tuesday 04/02/2024, 22:18:42
 * 
 * Image Information
 * -----------------
 * game.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAME_H
#define GAME_H

extern const unsigned short game[38400];
#define GAME_SIZE 76800
#define GAME_LENGTH 38400
#define GAME_WIDTH 240
#define GAME_HEIGHT 160

#endif

