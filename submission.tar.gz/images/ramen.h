/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 ramen ramen.png 
 * Time-stamp: Sunday 03/31/2024, 20:18:25
 * 
 * Image Information
 * -----------------
 * ramen.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RAMEN_H
#define RAMEN_H

extern const unsigned short ramen[1850];
#define RAMEN_SIZE 3700
#define RAMEN_LENGTH 1850
#define RAMEN_WIDTH 50
#define RAMEN_HEIGHT 37

#endif

