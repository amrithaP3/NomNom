/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 castle castle.png 
 * Time-stamp: Tuesday 04/02/2024, 01:41:43
 * 
 * Image Information
 * -----------------
 * castle.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CASTLE_H
#define CASTLE_H

extern const unsigned short castle[1850];
#define CASTLE_SIZE 3700
#define CASTLE_LENGTH 1850
#define CASTLE_WIDTH 50
#define CASTLE_HEIGHT 37

#endif

