/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 smile2 smile2.png 
 * Time-stamp: Tuesday 04/02/2024, 20:00:07
 * 
 * Image Information
 * -----------------
 * smile2.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SMILE2_H
#define SMILE2_H

extern const unsigned short smile2[225];
#define SMILE2_SIZE 450
#define SMILE2_LENGTH 225
#define SMILE2_WIDTH 15
#define SMILE2_HEIGHT 15

#endif

