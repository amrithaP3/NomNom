/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 donut donut.png 
 * Time-stamp: Tuesday 04/02/2024, 14:38:35
 * 
 * Image Information
 * -----------------
 * donut.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DONUT_H
#define DONUT_H

extern const unsigned short donut[225];
#define DONUT_SIZE 450
#define DONUT_LENGTH 225
#define DONUT_WIDTH 15
#define DONUT_HEIGHT 15

#endif

