/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 pizza pizza.png 
 * Time-stamp: Sunday 03/31/2024, 20:18:02
 * 
 * Image Information
 * -----------------
 * pizza.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PIZZA_H
#define PIZZA_H

extern const unsigned short pizza[1850];
#define PIZZA_SIZE 3700
#define PIZZA_LENGTH 1850
#define PIZZA_WIDTH 50
#define PIZZA_HEIGHT 37

#endif

